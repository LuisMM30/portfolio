import Navbar from './components/layout/Navbar'
import Footer from './components/layout/Footer'
import Hero from './components/sections/Hero'
import QuickProfile from './components/sections/QuickProfile'
import Projects from './components/sections/Projects'
import Experience from './components/sections/Experience'
import Capabilities from './components/sections/Capabilities'
import TechStack from './components/sections/TechStack'
import Tools from './components/sections/Tools'
import WorkProcess from './components/sections/WorkProcess'
import Education from './components/sections/Education'
import About from './components/sections/About'
import Contact from './components/sections/Contact'

function App() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <QuickProfile />
        <Projects />
        <Experience />
        <Capabilities />
        <TechStack />
        <Tools />
        <WorkProcess />
        <Education />
        <About />
        <Contact />
      </main>
      <Footer />
    </>
  )
}

export default App
