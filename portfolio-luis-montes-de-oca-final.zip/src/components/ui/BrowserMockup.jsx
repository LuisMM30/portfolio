export default function BrowserMockup({ src, alt, url }) {
  return (
    <figure className="border border-border bg-bg-secondary">
      {/* Chrome bar */}
      <div className="flex items-center gap-3 px-3.5 py-2.5 border-b border-border bg-bg-secondary">
        <div className="flex gap-1.5 shrink-0" aria-hidden="true">
          <span className="w-2.5 h-2.5 rounded-full bg-online/70" />
          <span className="w-2.5 h-2.5 rounded-full bg-private/70" />
          <span className="w-2.5 h-2.5 rounded-full bg-border-strong" />
        </div>
        <div className="flex-1 min-w-0 flex items-center gap-1.5 px-2 py-1 bg-bg-primary border border-border">
          <svg
            className="w-2.5 h-2.5 text-text-muted shrink-0"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <rect x="3" y="11" width="18" height="11" rx="2" />
            <path d="M7 11V7a5 5 0 0 1 10 0v4" />
          </svg>
          <span className="u-label text-text-muted truncate normal-case tracking-normal">
            {url || alt}
          </span>
        </div>
      </div>

      {/* Screen */}
      <div className="aspect-[16/10] overflow-hidden bg-bg-primary">
        <img
          src={src}
          alt={alt}
          loading="lazy"
          className="w-full h-full object-cover object-top transition-transform duration-700 hover:scale-[1.015]"
        />
      </div>
    </figure>
  )
}
