import { experiences } from '../../data/experience'
import SectionHeading from '../ui/SectionHeading'

export default function Experience() {
  return (
    <section id="experiencia" className="py-24 md:py-36">
      <div className="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8">
        <SectionHeading
          index="02"
          title="Experiencia"
          subtitle="Colaboraciones, prácticas y proyectos desarrollados para empresas y clientes reales."
        />

        <ol>
          {experiences.map((item, i) => (
            <li
              key={item.org + item.period}
              className="py-10 md:py-12 first:pt-0 last:pb-0 border-b border-border last:border-b-0"
            >
              <div className="grid lg:grid-cols-12 gap-6 lg:gap-10">
                {/* Meta column */}
                <div className="lg:col-span-3">
                  <p className="font-mono text-xs text-text-muted">{item.period}</p>
                  <p className="u-label text-text-muted mt-3">
                    {String(i + 1).padStart(2, '0')} / {item.kind}
                  </p>
                </div>

                {/* Content */}
                <div className="lg:col-span-9">
                  <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
                    <h3 className="text-2xl md:text-3xl font-semibold tracking-tight text-text-primary">
                      {item.role}
                    </h3>
                    <span className="u-label text-text-secondary">{item.org}</span>
                  </div>

                  <p className="text-text-secondary leading-relaxed mt-4 max-w-3xl">
                    {item.summary}
                  </p>

                  <p className="mt-5 font-mono text-xs text-text-muted flex flex-wrap gap-x-2 gap-y-1">
                    {item.technologies.map((tech, idx) => (
                      <span key={tech} className="inline-flex items-baseline gap-2">
                        {idx > 0 && <span aria-hidden="true">/</span>}
                        <span className="hover:text-accent transition-colors cursor-default">
                          {tech}
                        </span>
                      </span>
                    ))}
                  </p>
                </div>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
