import { ArrowRight, ArrowDownRight } from 'lucide-react'
import { site } from '../../data/site'
import Button from '../ui/Button'
import DownloadCVButton from '../ui/DownloadCVButton'

const specRows = [
  { label: 'Rol', value: site.role },
  { label: 'Base', value: site.location },
  { label: 'Formación', value: 'Téc. Sup. Desarrollo de Aplicaciones Web' },
  { label: 'Estado', value: 'Disponible para nuevas oportunidades', live: true },
  { label: 'Stack', value: 'React · PHP · WordPress' },
]

export default function Hero() {
  const year = new Date().getFullYear()

  return (
    <section
      id="inicio"
      className="relative min-h-screen flex flex-col pt-28 md:pt-36 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8 w-full flex-1 flex flex-col">
        <div className="flex-1 flex flex-col justify-center py-10">
          {/* Masthead meta */}
          <p className="u-label text-text-muted flex items-center gap-3">
            <span className="inline-block w-1.5 h-1.5 bg-accent" aria-hidden="true" />
            Portfolio — {site.role} — {year}
          </p>

          <div className="grid lg:grid-cols-12 gap-10 lg:gap-16 mt-8 lg:mt-12 items-end">
            {/* Headline */}
            <div className="lg:col-span-8">
              <h1 className="display text-[clamp(2.7rem,9.5vw,7rem)] text-text-primary">
                {site.headline}
              </h1>

              <p className="text-text-secondary text-lg md:text-xl leading-relaxed mt-8 max-w-xl">
                {site.subheadline}
              </p>

              <div className="flex flex-col sm:flex-row flex-wrap gap-3 mt-10">
                <Button href="#proyectos" variant="primary" size="lg">
                  Ver proyectos
                  <ArrowRight size={18} aria-hidden="true" />
                </Button>
                <Button href="#contacto" variant="secondary" size="lg">
                  Contactar
                </Button>
                <DownloadCVButton variant="ghost" size="lg" label="Descargar CV" />
              </div>
            </div>

            {/* Spec sheet */}
            <aside className="lg:col-span-4 border border-border divide-y divide-border bg-bg-secondary/60 self-stretch">
              {specRows.map((row) => (
                <div key={row.label} className="flex items-start justify-between gap-4 px-4 py-3.5">
                  <span className="u-label text-text-muted pt-0.5 shrink-0">{row.label}</span>
                  <span
                    className={
                      row.live
                        ? 'inline-flex items-center gap-2 text-right text-sm text-online font-medium'
                        : 'text-right text-sm text-text-primary font-medium'
                    }
                  >
                    {row.live && (
                      <span
                        className="relative flex w-2 h-2 shrink-0"
                        aria-hidden="true"
                      >
                        <span className="absolute inline-flex h-full w-full rounded-full bg-online opacity-50 animate-ping" />
                        <span className="relative inline-flex w-2 h-2 rounded-full bg-online" />
                      </span>
                    )}
                    {row.value}
                  </span>
                </div>
              ))}
            </aside>
          </div>
        </div>

        {/* Kinetic identity strip */}
        <div
          className="marquee border-t border-border mt-10 py-5"
          aria-hidden="true"
        >
          <div className="marquee-track">
            {[0, 1].map((dup) => (
              <span
                key={dup}
                className="stroke-text display text-[16vw] md:text-[8.5rem] whitespace-nowrap pr-0"
              >
                {`Luis Montes de Oca ✦ Desarrollador Web ✦ Madrid ✦ ${year} ✦ `}
              </span>
            ))}
          </div>
        </div>
      </div>

      <a
        href="#perfil"
        className="hidden md:inline-flex items-center gap-2 absolute bottom-24 right-6 lg:right-10 text-text-muted hover:text-accent transition-colors u-label"
        aria-label="Bajar al perfil"
      >
        Scroll
        <ArrowDownRight size={16} />
      </a>
    </section>
  )
}
