import { site } from '../../data/site'
import { aptitudes } from '../../data/skills'
import SectionHeading from '../ui/SectionHeading'

export default function About() {
  return (
    <section id="sobre-mi" className="py-24 md:py-36">
      <div className="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8">
        <SectionHeading
          index="08"
          title="Construyo productos web para necesidades reales."
          subtitle={site.status}
        />

        <div className="grid lg:grid-cols-2 gap-x-14 gap-y-8 max-w-5xl">
          <div className="space-y-5 text-lg text-text-secondary leading-relaxed">
            <p>
              Soy desarrollador web con formación en Desarrollo de Aplicaciones Web y experiencia
              en proyectos para clientes y empresas reales.
            </p>
            <p>
              He trabajado en comercio electrónico, webs para negocios y en el desarrollo desde
              cero de una plataforma de gestión de pedidos con React y MongoDB.
            </p>
          </div>
          <div className="space-y-5 text-lg text-text-secondary leading-relaxed lg:pt-14">
            <p>
              También integro herramientas de inteligencia artificial en mi flujo de trabajo para
              investigar soluciones, acelerar el desarrollo y mejorar la productividad.
            </p>
            <p>
              Busco nuevas oportunidades donde pueda aportar valor en proyectos tecnológicos y
              seguir creciendo.
            </p>
            <p className="u-label text-text-muted pt-2">Base — {site.location}</p>
          </div>
        </div>

        <div className="mt-24 md:mt-32">
          <p className="u-label text-text-muted mb-8">Más allá del código</p>
          <ol className="grid sm:grid-cols-2 lg:grid-cols-3 border-b border-border">
            {aptitudes.map((aptitude, i) => (
              <li
                key={aptitude}
                className="flex items-baseline gap-4 py-5 border-t border-border pr-6"
              >
                <span className="font-mono text-xs text-accent shrink-0">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <span className="text-text-primary font-medium leading-snug">{aptitude}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  )
}
