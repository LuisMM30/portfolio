import { skillCategories } from '../../data/skills'
import SectionHeading from '../ui/SectionHeading'

export default function TechStack() {
  return (
    <section id="tecnologias" className="py-24 md:py-36">
      <div className="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8">
        <SectionHeading
          index="04"
          title="Tecnologías con las que trabajo"
          subtitle="Lenguajes, plataformas y herramientas que utilizo en proyectos reales."
        />

        <ol className="border-b border-border">
          {skillCategories.map((category) => (
            <li key={category.title}>
              <div className="grid md:grid-cols-[260px_1fr] gap-x-10 gap-y-4 py-6 md:py-7 border-t border-border items-baseline">
                <h3 className="u-label text-text-muted">{category.title}</h3>
                <p className="font-medium text-text-primary flex flex-wrap gap-x-3 gap-y-1.5">
                  {category.skills.map((skill, i) => (
                    <span key={skill} className="inline-flex items-baseline gap-3">
                      {i > 0 && <span className="text-text-muted font-normal" aria-hidden="true">/</span>}
                      <span className="cursor-default hover:text-accent transition-colors">
                        {skill}
                      </span>
                    </span>
                  ))}
                </p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
