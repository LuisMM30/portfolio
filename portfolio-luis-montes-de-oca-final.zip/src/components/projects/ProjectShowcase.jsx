import { ExternalLink, ArrowRight } from 'lucide-react'
import Badge from '../ui/Badge'
import Button from '../ui/Button'
import BrowserMockup from '../ui/BrowserMockup'
import { cn } from '../../utils/cn'

export default function ProjectShowcase({ project, index, onOpenModal }) {
  const reversed = index % 2 !== 0
  const badgeVariant = project.status === 'online' ? 'online' : 'private'

  const handleOpen = () => {
    if (project.ctaType === 'modal') onOpenModal(project)
  }

  return (
    <article className="group">
      {/* Entry header */}
      <header className="flex items-center justify-between gap-4 pb-3 border-b border-border mb-10 md:mb-14">
        <div className="flex items-baseline gap-4 min-w-0">
          <span className="font-mono text-sm text-accent">{project.id}</span>
          <span className="u-label text-text-muted truncate">{project.category}</span>
        </div>
        <Badge variant={badgeVariant}>{project.statusLabel}</Badge>
      </header>

      <div className="grid lg:grid-cols-12 gap-10 lg:gap-16 items-center">
        {/* Text */}
        <div className={cn('lg:col-span-5', reversed ? 'lg:order-2' : 'lg:order-1')}>
          <h3 className="display text-3xl md:text-4xl xl:text-5xl text-text-primary">
            {project.title}
          </h3>

          <p className="text-text-secondary leading-relaxed mt-6 text-lg max-w-md">
            {project.description}
          </p>

          <p className="mt-6 text-sm flex flex-wrap gap-x-2 gap-y-1 font-mono text-text-muted">
            {project.technologies.map((tech, i) => (
              <span key={tech} className="inline-flex items-baseline gap-2">
                {i > 0 && <span aria-hidden="true">/</span>}
                <span className="hover:text-accent transition-colors cursor-default">{tech}</span>
              </span>
            ))}
          </p>

          <div className="mt-8">
            {project.ctaType === 'external' ? (
              <Button href={project.url} external variant="primary" size="md">
                {project.cta}
                <ExternalLink size={16} aria-hidden="true" />
              </Button>
            ) : (
              <div className="flex flex-wrap items-center gap-5">
                <Button variant="primary" size="md" onClick={handleOpen}>
                  {project.cta}
                  <ArrowRight size={16} aria-hidden="true" />
                </Button>
                <button
                  type="button"
                  onClick={handleOpen}
                  className="u-label text-text-muted hover:text-accent transition-colors link-underline pb-0.5 cursor-pointer"
                >
                  Ver case study
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Figures */}
        <div className={cn('lg:col-span-7', reversed ? 'lg:order-1' : 'lg:order-2')}>
          <div className={cn('flex gap-4 md:gap-6 items-start', project.images.mobile && 'flex-col sm:flex-row')}>
            <div className="flex-1 min-w-0">
              <BrowserMockup
                src={project.images.desktop}
                alt={`Vista previa de ${project.title}`}
                url={project.url || 'proyecto-privado'}
              />
              <p className="u-label text-text-muted mt-2.5">FIG. {project.id} — escritorio</p>
            </div>
            {project.images.mobile && (
              <div className="sm:w-[38%] lg:w-[30%] shrink-0">
                <BrowserMockup
                  src={project.images.mobile}
                  alt={`Vista previa de ${project.title} — vista móvil`}
                  url={project.url || 'proyecto-privado'}
                />
                <p className="u-label text-text-muted mt-2.5">FIG. {project.id}b — móvil</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </article>
  )
}
