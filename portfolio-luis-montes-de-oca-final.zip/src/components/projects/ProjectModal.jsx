import { useEffect, useRef } from 'react'
import { X, ExternalLink } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import Badge from '../ui/Badge'
import Button from '../ui/Button'

function Section({ label, children }) {
  return (
    <section className="pt-6 border-t border-border">
      <h3 className="u-label text-text-muted mb-4">{label}</h3>
      {children}
    </section>
  )
}

export default function ProjectModal({ project, isOpen, onClose }) {
  const closeButtonRef = useRef(null)

  useEffect(() => {
    if (!isOpen) return

    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose()
    }

    document.addEventListener('keydown', handleKeyDown)
    document.body.style.overflow = 'hidden'
    closeButtonRef.current?.focus()

    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.body.style.overflow = ''
    }
  }, [isOpen, onClose])

  if (!project?.details) return null

  const { details } = project

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            className="fixed inset-0 z-[60] bg-black/70"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            aria-hidden="true"
          />

          <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center p-0 sm:p-6 pointer-events-none">
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-labelledby="modal-title"
              className="pointer-events-auto w-full sm:max-w-3xl lg:max-w-4xl max-h-[92vh] sm:max-h-[88vh] overflow-y-auto bg-bg-primary border sm:border border-border"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 24 }}
              transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
            >
              {/* Header */}
              <div className="sticky top-0 z-10 flex items-center justify-between gap-4 px-5 md:px-8 py-4 bg-bg-primary border-b border-border">
                <div className="flex items-center gap-4 min-w-0">
                  <span className="font-mono text-sm text-accent shrink-0" aria-hidden="true">
                    {project.id}
                  </span>
                  <div className="min-w-0">
                    <Badge
                      variant={project.status === 'online' ? 'online' : 'private'}
                      className="mb-1.5"
                    >
                      {details.status}
                    </Badge>
                    <h2
                      id="modal-title"
                      className="text-lg md:text-2xl font-semibold text-text-primary tracking-tight truncate"
                    >
                      {project.title}
                    </h2>
                  </div>
                </div>
                <button
                  ref={closeButtonRef}
                  type="button"
                  onClick={onClose}
                  className="p-2.5 border border-border text-text-secondary hover:text-text-primary hover:border-border-strong transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center shrink-0"
                  aria-label="Cerrar"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="px-5 md:px-8 py-2">
                <Section label="Contexto">
                  <p className="text-text-secondary leading-relaxed">{details.context}</p>
                </Section>

                <Section label="El proyecto">
                  <p className="text-text-secondary leading-relaxed">{details.project}</p>
                </Section>

                {details.subProjects && (
                  <Section label="Proyectos">
                    <div className="grid sm:grid-cols-2 gap-6">
                      {details.subProjects.map((sub) => (
                        <article key={sub.name}>
                          <div className="border border-border bg-bg-secondary">
                            <img
                              src={sub.image}
                              alt={sub.name}
                              loading="lazy"
                              className="w-full aspect-video object-cover object-top"
                            />
                          </div>
                          <p className="u-label text-text-muted mt-2.5 mb-1">{sub.category}</p>
                          <h4 className="font-semibold text-text-primary">{sub.name}</h4>
                          <p className="text-sm text-text-secondary mt-1.5 mb-3">
                            {sub.description}
                          </p>
                          <p className="text-xs font-mono text-text-muted flex flex-wrap gap-x-2">
                            {sub.technologies.map((tech, i) => (
                              <span key={tech} className="inline-flex items-baseline gap-2">
                                {i > 0 && <span aria-hidden="true">/</span>}
                                {tech}
                              </span>
                            ))}
                          </p>
                        </article>
                      ))}
                    </div>
                  </Section>
                )}

                {details.features && (
                  <Section label="Funcionalidades">
                    <ul>
                      {details.features.map((feature, i) => (
                        <li
                          key={feature}
                          className="flex items-baseline gap-4 py-3 border-b border-border/60 last:border-b-0"
                        >
                          <span className="font-mono text-xs text-accent shrink-0">
                            {String(i + 1).padStart(2, '0')}
                          </span>
                          <span className="text-text-secondary text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </Section>
                )}

                <Section label="Tecnologías">
                  <p className="font-mono text-sm text-text-primary flex flex-wrap gap-x-2.5 gap-y-1">
                    {details.technologies.map((tech, i) => (
                      <span key={tech} className="inline-flex items-baseline gap-2.5">
                        {i > 0 && <span className="text-text-muted" aria-hidden="true">/</span>}
                        {tech}
                      </span>
                    ))}
                  </p>
                </Section>

                {details.gallery && (
                  <Section label="Galería">
                    <div className="grid gap-6">
                      {details.gallery.map((img, i) => (
                        <div key={img}>
                          <div className="border border-border bg-bg-secondary">
                            <img
                              src={img}
                              alt={`${project.title} — captura ${i + 1}`}
                              loading="lazy"
                              className="w-full h-auto"
                            />
                          </div>
                          <p className="u-label text-text-muted mt-2">
                            FIG. {i + 1} — {project.title}
                          </p>
                        </div>
                      ))}
                    </div>
                  </Section>
                )}

                <div className="pt-8 pb-8 flex flex-col sm:flex-row sm:items-center gap-4 sm:justify-between">
                  <div className="flex items-center gap-3">
                    <span className="u-label text-text-muted">Estado</span>
                    <Badge variant={project.status === 'online' ? 'online' : 'private'}>
                      {details.status}
                    </Badge>
                  </div>
                  {project.url && (
                    <Button href={project.url} external variant="primary">
                      Visitar web
                      <ExternalLink size={16} aria-hidden="true" />
                    </Button>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  )
}
