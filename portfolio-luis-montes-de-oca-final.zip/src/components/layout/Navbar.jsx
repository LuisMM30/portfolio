import { useEffect, useState } from 'react'
import { Menu, X, ArrowUpRight } from 'lucide-react'
import { navLinks, site } from '../../data/site'
import Button from '../ui/Button'
import ThemeToggle from '../ui/ThemeToggle'
import DownloadCVButton from '../ui/DownloadCVButton'
import { cn } from '../../utils/cn'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [progress, setProgress] = useState(0)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      const y = window.scrollY
      setScrolled(y > 16)
      const max = document.documentElement.scrollHeight - window.innerHeight
      setProgress(max > 0 ? Math.min(y / max, 1) : 0)
    }
    handleScroll()
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [mobileOpen])

  const handleNavClick = () => setMobileOpen(false)

  return (
    <header
      className={cn(
        'fixed top-0 left-0 right-0 z-50 border-b transition-colors duration-300',
        scrolled || mobileOpen ? 'bg-bg-primary border-border' : 'bg-transparent border-transparent',
      )}
    >
      <nav
        className="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8 flex items-center justify-between gap-4 h-16 md:h-20"
        aria-label="Navegación principal"
      >
        <a
          href="#inicio"
          className="inline-flex items-center gap-2.5 text-sm md:text-base font-semibold text-text-primary tracking-tight hover:text-accent transition-colors shrink-0"
          onClick={(e) => {
            e.preventDefault()
            window.scrollTo({ top: 0, behavior: 'smooth' })
            setMobileOpen(false)
          }}
        >
          <span className="inline-block w-2.5 h-2.5 bg-accent" aria-hidden="true" />
          {site.name}
        </a>

        <ul className="hidden lg:flex items-center gap-7 xl:gap-9">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                onClick={handleNavClick}
                className="u-label text-text-secondary hover:text-accent transition-colors link-underline pb-1"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden lg:flex items-center gap-2.5">
          <ThemeToggle />
          <DownloadCVButton variant="secondary" size="sm" iconOnly />
          <Button href="#contacto" variant="primary" size="sm">
            Contactar
          </Button>
        </div>

        {/* Mobile controls */}
        <div className="flex lg:hidden items-center gap-2">
          <ThemeToggle />
          <DownloadCVButton variant="secondary" size="sm" iconOnly />
          <button
            type="button"
            className="p-2 text-text-secondary hover:text-text-primary transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Cerrar menú' : 'Abrir menú'}
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </nav>

      {/* Reading progress */}
      <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-transparent" aria-hidden="true">
        <div
          className="h-full bg-accent origin-left"
          style={{ transform: `scaleX(${progress})` }}
        />
      </div>

      {/* Mobile menu */}
      <div
        className={cn(
          'lg:hidden fixed inset-0 top-16 md:top-20 bg-bg-primary transition-all duration-300',
          mobileOpen ? 'opacity-100 visible' : 'opacity-0 invisible pointer-events-none',
        )}
      >
        <div className="h-full overflow-y-auto px-5 sm:px-6 py-6">
          <ul>
            {navLinks.map((link, i) => (
              <li key={link.href} className="border-b border-border">
                <a
                  href={link.href}
                  onClick={handleNavClick}
                  className="group flex items-center justify-between py-5 text-2xl font-semibold tracking-tight text-text-primary hover:text-accent transition-colors"
                >
                  <span>{link.label}</span>
                  <span className="u-label text-text-muted group-hover:text-accent transition-colors">
                    0{i + 1} ↗
                  </span>
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-8 flex flex-col gap-3">
            <DownloadCVButton variant="secondary" size="lg" className="w-full" onClick={handleNavClick} />
            <Button
              href="#contacto"
              variant="primary"
              size="lg"
              className="w-full"
              onClick={handleNavClick}
            >
              Contactar
              <ArrowUpRight size={18} aria-hidden="true" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}
