import { Download, ArrowUpRight } from 'lucide-react'
import { cv, site } from '../../data/site'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="border-t border-border">
      <div className="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8 pt-14 md:pt-20 pb-8">
        <div className="grid md:grid-cols-3 gap-12">
          <div>
            <p className="display text-2xl md:text-3xl text-text-primary">
              {site.name}
            </p>
            <p className="mt-2 text-sm text-text-secondary">{site.role} — {site.location}</p>
            <p className="mt-1 text-xs text-text-muted">{site.education}</p>
          </div>

          <div>
            <p className="u-label text-text-muted mb-4 pb-2 border-b border-border">Contacto</p>
            <ul className="space-y-2.5 text-sm">
              <li>
                <a
                  href={`mailto:${site.email}`}
                  className="inline-flex items-center gap-2 text-text-secondary hover:text-accent transition-colors link-underline"
                >
                  {site.email}
                  <ArrowUpRight size={13} aria-hidden="true" />
                </a>
              </li>
              <li>
                <a
                  href={site.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-text-secondary hover:text-accent transition-colors link-underline"
                >
                  LinkedIn
                  <ArrowUpRight size={13} aria-hidden="true" />
                </a>
              </li>
            </ul>
          </div>

          <div>
            <p className="u-label text-text-muted mb-4 pb-2 border-b border-border">Documentos</p>
            <ul className="space-y-2.5 text-sm">
              <li>
                <a
                  href={cv.url}
                  download={cv.fileName}
                  className="inline-flex items-center gap-2 text-text-secondary hover:text-accent transition-colors link-underline"
                >
                  <Download size={14} aria-hidden="true" />
                  Descargar CV
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-5 border-t border-border flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <p className="u-label text-text-muted">
            © {year} — {site.name}
          </p>
          <p className="u-label text-text-muted">
            {site.location} — Portfolio {year}
          </p>
        </div>
      </div>
    </footer>
  )
}
