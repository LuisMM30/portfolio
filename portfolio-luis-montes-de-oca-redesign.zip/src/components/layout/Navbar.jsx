import { useEffect, useRef, useState } from 'react'
import { ArrowUpRight } from 'lucide-react'
import { site } from '../../data/site'
import { sectionIndex } from '../../data/navigation'
import ThemeToggle from '../ui/ThemeToggle'
import DownloadCVButton from '../ui/DownloadCVButton'
import { cn } from '../../utils/cn'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [progress, setProgress] = useState(0)
  const [open, setOpen] = useState(false)
  const toggleRef = useRef(null)
  const panelRef = useRef(null)

  useEffect(() => {
    let raf = 0
    const onScroll = () => {
      if (raf) return
      raf = requestAnimationFrame(() => {
        raf = 0
        const y = window.scrollY
        setScrolled(y > 16)
        const max = document.documentElement.scrollHeight - window.innerHeight
        setProgress(max > 0 ? Math.min(y / max, 1) : 0)
      })
    }
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => {
      window.removeEventListener('scroll', onScroll)
      if (raf) cancelAnimationFrame(raf)
    }
  }, [])

  // Lock scroll + full keyboard support while the index overlay is open.
  useEffect(() => {
    if (!open) return undefined

    document.body.style.overflow = 'hidden'
    const items = panelRef.current?.querySelectorAll('a, button')
    items?.[0]?.focus()

    const onKeyDown = (e) => {
      if (e.key === 'Escape') {
        setOpen(false)
        toggleRef.current?.focus()
        return
      }
      if (e.key !== 'Tab') return
      const list = Array.from(items ?? [])
      if (list.length === 0) return
      const first = list[0]
      const last = list[list.length - 1]
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault()
        last.focus()
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault()
        first.focus()
      }
    }

    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('keydown', onKeyDown)
      document.body.style.overflow = ''
    }
  }, [open])

  const close = () => setOpen(false)

  return (
    <>
      <header
        className={cn(
          'fixed inset-x-0 top-0 z-50 border-b transition-colors duration-300',
          scrolled || open ? 'border-border bg-bg-primary' : 'border-transparent bg-transparent',
        )}
      >
        <nav
          aria-label="Navegación principal"
          className="mx-auto flex h-16 items-center justify-between gap-4 px-5 sm:px-6 md:h-20 lg:px-8"
        >
          <a
            href="#inicio"
            className="group inline-flex shrink-0 items-center gap-2.5 text-sm font-semibold tracking-tight text-text-primary transition-colors hover:text-accent md:text-base"
            onClick={(e) => {
              e.preventDefault()
              close()
              window.scrollTo({ top: 0, behavior: 'smooth' })
            }}
          >
            <span className="inline-block h-2.5 w-2.5 bg-accent" aria-hidden="true" />
            {site.name}
          </a>

          <div className="flex items-center gap-2.5">
            <ThemeToggle />
            <DownloadCVButton variant="secondary" size="sm" iconOnly />
            <button
              ref={toggleRef}
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="index-overlay"
              data-cursor="view"
              className="u-label inline-flex min-h-[44px] items-center gap-2 border border-border px-4 text-text-secondary transition-colors hover:border-border-strong hover:text-text-primary"
            >
              <span
                className="inline-flex flex-col gap-[3px]"
                aria-hidden="true"
              >
                <span className="block h-px w-4 bg-current" />
                <span className="block h-px w-4 bg-current" />
              </span>
              Index
            </button>
          </div>
        </nav>

        {/* Reading progress */}
        <div className="absolute inset-x-0 bottom-0 h-[2px]" aria-hidden="true">
          <div
            className="h-full origin-left bg-accent"
            style={{ transform: `scaleX(${progress})` }}
          />
        </div>
      </header>

      {/* INDEX overlay */}
      <div
        id="index-overlay"
        ref={panelRef}
        className={cn(
          'fixed inset-0 z-[80] flex flex-col bg-bg-primary transition-[opacity,visibility] duration-300',
          open ? 'visible opacity-100' : 'invisible opacity-0',
        )}
        role="dialog"
        aria-modal="true"
        aria-label="Índice del portfolio"
        hidden={!open}
      >
        <div className="mx-auto flex w-full max-w-7xl flex-1 flex-col px-5 pt-24 sm:px-6 md:pt-28 lg:px-8">
          <p className="u-label mb-8 flex items-center justify-between border-b border-border pb-4 text-text-muted">
            <span>Index — {site.name}</span>
            <span>ESC para cerrar</span>
          </p>

          <ol className="flex-1 overflow-y-auto">
            {sectionIndex.map((section, i) => (
              <li key={section.id} className="border-b border-border">
                <a
                  href={`#${section.id}`}
                  onClick={close}
                  className="group flex items-baseline justify-between gap-6 py-4 transition-colors md:py-5"
                >
                  <span className="flex items-baseline gap-5 md:gap-8">
                    <span className="u-label shrink-0 text-accent">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className="display text-3xl text-text-primary transition-all duration-300 group-hover:translate-x-3 group-hover:text-accent sm:text-4xl md:text-6xl">
                      {section.label}
                    </span>
                  </span>
                  <ArrowUpRight
                    size={22}
                    className="shrink-0 self-center text-text-muted transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-accent"
                    aria-hidden="true"
                  />
                </a>
              </li>
            ))}
          </ol>

          <div className="flex flex-col gap-3 border-t border-border py-6 sm:flex-row sm:items-center sm:justify-between">
            <DownloadCVButton variant="secondary" size="lg" className="w-full sm:w-auto" onClick={close} />
            <p className="u-label text-text-muted">
              {site.email} — {site.location}
            </p>
          </div>
        </div>
      </div>
    </>
  )
}
