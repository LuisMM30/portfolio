import { useEffect, useState } from 'react'
import { Download, ArrowUpRight } from 'lucide-react'
import { cv, site } from '../../data/site'

export default function Footer() {
  const year = new Date().getFullYear()
  const [theme, setTheme] = useState(
    () => document.documentElement.dataset.theme || 'dark',
  )

  useEffect(() => {
    const observer = new MutationObserver(() => {
      setTheme(document.documentElement.dataset.theme || 'dark')
    })
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] })
    return () => observer.disconnect()
  }, [])

  const systemRows = [
    { label: 'Role', value: site.role.toUpperCase() },
    { label: 'Location', value: site.location.replace(', España', '').toUpperCase() },
    { label: 'Stack', value: 'REACT / JAVASCRIPT / PHP' },
    { label: 'Theme', value: theme.toUpperCase() },
    { label: 'Build', value: String(year) },
  ]

  return (
    <footer className="border-t border-border">
      <div className="mx-auto max-w-7xl px-5 pb-8 pt-14 sm:px-6 md:pt-20 lg:px-8">
        <div className="grid gap-12 md:grid-cols-4">
          <div>
            <p className="display text-2xl text-text-primary md:text-3xl">{site.name}</p>
            <p className="mt-2 text-sm text-text-secondary">
              {site.role} — {site.location}
            </p>
            <p className="mt-1 text-xs text-text-muted">{site.education}</p>
          </div>

          <div>
            <p className="u-label mb-4 border-b border-border pb-2 text-text-muted">Contacto</p>
            <ul className="space-y-2.5 text-sm">
              <li>
                <a
                  href={`mailto:${site.email}`}
                  className="link-underline inline-flex items-center gap-2 text-text-secondary transition-colors hover:text-accent"
                >
                  {site.email}
                  <ArrowUpRight size={13} aria-hidden="true" />
                </a>
              </li>
              <li>
                <a
                  href={site.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="link-underline inline-flex items-center gap-2 text-text-secondary transition-colors hover:text-accent"
                >
                  LinkedIn
                  <ArrowUpRight size={13} aria-hidden="true" />
                </a>
              </li>
            </ul>
          </div>

          <div>
            <p className="u-label mb-4 border-b border-border pb-2 text-text-muted">Documentos</p>
            <ul className="space-y-2.5 text-sm">
              <li>
                <a
                  href={cv.url}
                  download={cv.fileName}
                  className="link-underline inline-flex items-center gap-2 text-text-secondary transition-colors hover:text-accent"
                >
                  <Download size={14} aria-hidden="true" />
                  Descargar CV
                </a>
              </li>
            </ul>
          </div>

          {/* SYSTEM / INFO — real values only */}
          <div>
            <p className="u-label mb-4 border-b border-border pb-2 text-text-muted">System / Info</p>
            <dl className="space-y-2">
              {systemRows.map((row) => (
                <div key={row.label} className="flex items-baseline justify-between gap-3">
                  <dt className="u-label text-text-muted">{row.label}</dt>
                  <dd className="font-mono text-xs text-text-secondary">{row.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>

        <div className="mt-16 flex flex-col justify-between gap-2 border-t border-border pt-5 sm:flex-row sm:items-center">
          <p className="u-label text-text-muted">
            © {year} — {site.name}
          </p>
          <p className="u-label text-text-muted">
            {site.location} — Portfolio {year}
          </p>
        </div>
      </div>
    </footer>
  )
}
