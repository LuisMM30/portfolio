import { workSteps } from '../../data/skills'
import SectionHeading from '../ui/SectionHeading'

export default function WorkProcess() {
  return (
    <section id="proceso" className="py-24 md:py-36">
      <div className="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8">
        <SectionHeading
          index="06"
          title="De la idea al producto"
          subtitle="Un proceso claro y honesto para convertir una necesidad en una web que funciona."
        />

        <ol className="grid sm:grid-cols-2 lg:grid-cols-4 gap-x-10 gap-y-12 lg:gap-x-8">
          {workSteps.map((step) => (
            <li key={step.number} className="border-t border-border pt-6">
              <p className="font-mono text-4xl md:text-5xl text-text-muted leading-none">
                {step.number}
              </p>
              <h3 className="mt-6 text-xl md:text-2xl font-semibold tracking-tight text-text-primary">
                {step.title}
              </h3>
              <p className="text-text-secondary leading-relaxed mt-3 text-sm md:text-base">
                {step.description}
              </p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
