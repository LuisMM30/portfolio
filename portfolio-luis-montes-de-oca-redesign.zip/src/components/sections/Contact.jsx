import { useState } from 'react'
import { ArrowUpRight, ChevronDown, Send, CheckCircle, AlertCircle } from 'lucide-react'
import { site, contactReasons } from '../../data/site'
import SectionHeading from '../ui/SectionHeading'
import Button from '../ui/Button'
import DownloadCVButton from '../ui/DownloadCVButton'

const fieldClasses =
  'w-full bg-transparent border-0 border-b border-border py-3 text-text-primary placeholder:text-text-muted focus:border-accent focus:outline-none transition-colors min-h-[46px]'

export default function Contact() {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    reason: '',
    message: '',
  })
  const [status, setStatus] = useState('idle') // idle | success | error

  const hasEndpoint = Boolean(import.meta.env.VITE_CONTACT_ENDPOINT)

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormState((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setStatus('idle')

    const endpoint = import.meta.env.VITE_CONTACT_ENDPOINT

    if (!endpoint) {
      const subject = encodeURIComponent(`Contacto portfolio — ${formState.reason}`)
      const body = encodeURIComponent(
        `Nombre: ${formState.name}\nEmail: ${formState.email}\nMotivo: ${formState.reason}\n\n${formState.message}`,
      )
      window.location.href = `mailto:${site.email}?subject=${subject}&body=${body}`
      setStatus('success')
      return
    }

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formState),
      })

      if (!response.ok) throw new Error('Error al enviar')

      setStatus('success')
      setFormState({ name: '', email: '', reason: '', message: '' })
    } catch {
      setStatus('error')
    }
  }

  const rows = [
    {
      label: 'Email',
      value: site.email,
      href: `mailto:${site.email}`,
      external: false,
    },
    {
      label: 'LinkedIn',
      value: 'luis-montes-de-oca',
      href: site.linkedin,
      external: true,
    },
  ]

  return (
    <section id="contacto" className="relative pb-24 pt-24 md:pb-32 md:pt-36">
      <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
        <SectionHeading
          index="09"
          title="¿Hablamos?"
          subtitle="Si estás buscando un desarrollador o tienes un proyecto en mente, puedes ponerte en contacto conmigo."
        />

        {/* Typographic close */}
        <p
          className="display mt-6 select-none text-[clamp(2.6rem,8vw,7rem)] leading-[0.95] text-text-primary"
          aria-hidden="false"
        >
          Construyamos
          <br />
          <span className="stroke-text">algo real.</span>
        </p>

        <div className="mt-16 grid gap-x-14 gap-y-14 lg:grid-cols-12">
          {/* Direct channels */}
          <div className="lg:col-span-5">
            <ul className="divide-y divide-border border border-border">
              {rows.map((row) => (
                <li key={row.label}>
                  <a
                    href={row.href}
                    {...(row.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                    data-cursor="talk"
                    className="group flex items-center justify-between gap-4 px-5 py-4 transition-colors hover:bg-bg-secondary"
                  >
                    <span className="u-label text-text-muted">{row.label}</span>
                    <span className="inline-flex items-center gap-2 break-all text-right font-medium text-text-primary">
                      {row.value}
                      <ArrowUpRight
                        size={16}
                        className="text-text-muted transition-all duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-accent"
                        aria-hidden="true"
                      />
                    </span>
                  </a>
                </li>
              ))}
            </ul>

            <div className="mt-5 flex items-center justify-between gap-4 px-1">
              <div>
                <p className="u-label mb-1 text-text-muted">Currículum</p>
                <p className="text-sm text-text-secondary">
                  Experiencia y formación en detalle, en PDF.
                </p>
              </div>
              <DownloadCVButton variant="primary" size="md" label="Descargar CV" />
            </div>

            <p className="mt-8 max-w-sm text-xs leading-relaxed text-text-muted">
              ¿Prefieres el correo de siempre? Escríbeme directamente a{' '}
              <a
                href={`mailto:${site.email}`}
                className="link-underline text-text-secondary transition-colors hover:text-accent"
              >
                {site.email}
              </a>
              .
            </p>
          </div>

          {/* Form */}
          <div className="lg:col-span-7">
            <div className="border border-border bg-bg-secondary/40 px-6 py-8 md:px-10 md:py-10">
              <h3 className="display mb-8 text-2xl text-text-primary md:text-3xl">
                Cuéntame tu proyecto
              </h3>

              <form onSubmit={handleSubmit} className="space-y-7" noValidate>
                <div className="grid gap-x-8 gap-y-7 sm:grid-cols-2">
                  <div>
                    <label htmlFor="name" className="u-label mb-1.5 block text-text-muted">
                      Nombre
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      required
                      autoComplete="name"
                      value={formState.name}
                      onChange={handleChange}
                      className={fieldClasses}
                      placeholder="Tu nombre"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="u-label mb-1.5 block text-text-muted">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      autoComplete="email"
                      value={formState.email}
                      onChange={handleChange}
                      className={fieldClasses}
                      placeholder="tu@email.com"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="reason" className="u-label mb-1.5 block text-text-muted">
                    ¿Qué necesitas?
                  </label>
                  <div className="relative">
                    <select
                      id="reason"
                      name="reason"
                      required
                      value={formState.reason}
                      onChange={handleChange}
                      className={`${fieldClasses} appearance-none cursor-pointer pr-8`}
                    >
                      <option value="" disabled>
                        Selecciona una opción
                      </option>
                      {contactReasons.map((reason) => (
                        <option key={reason} value={reason}>
                          {reason}
                        </option>
                      ))}
                    </select>
                    <ChevronDown
                      size={16}
                      className="pointer-events-none absolute right-0 top-1/2 -translate-y-1/2 text-text-muted"
                      aria-hidden="true"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="message" className="u-label mb-1.5 block text-text-muted">
                    Mensaje
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    required
                    rows={4}
                    value={formState.message}
                    onChange={handleChange}
                    className={`${fieldClasses} min-h-[110px] resize-y`}
                    placeholder="Cuéntame sobre tu proyecto o consulta..."
                  />
                </div>

                <div className="flex flex-col gap-5 pt-1 sm:flex-row sm:items-center">
                  <Button type="submit" variant="primary" size="lg" data-cursor="talk">
                    Enviar mensaje
                    <Send size={16} aria-hidden="true" />
                  </Button>

                  <div aria-live="polite">
                    {status === 'success' && (
                      <p className="flex items-start gap-2 text-sm text-online" role="status">
                        <CheckCircle size={16} className="mt-0.5 shrink-0" aria-hidden="true" />
                        <span>
                          {hasEndpoint
                            ? 'Mensaje enviado. Gracias, te responderé lo antes posible.'
                            : 'Mensaje preparado: se abrirá tu cliente de correo para enviarlo.'}
                        </span>
                      </p>
                    )}
                    {status === 'error' && (
                      <p className="flex items-start gap-2 text-sm text-danger" role="alert">
                        <AlertCircle size={16} className="mt-0.5 shrink-0" aria-hidden="true" />
                        <span>
                          No se pudo enviar el mensaje. Inténtalo de nuevo o escríbeme a{' '}
                          {site.email}.
                        </span>
                      </p>
                    )}
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
