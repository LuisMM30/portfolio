import { useEffect, useRef, useState } from 'react'
import { experiences } from '../../data/experience'
import SectionHeading from '../ui/SectionHeading'

function extractYear(period) {
  const match = period.match(/\d{4}/g)
  return match ? match[match.length - 1] : '—'
}

export default function Experience() {
  const listRef = useRef(null)
  const [activeIndex, setActiveIndex] = useState(0)

  // Active entry drives the giant year + progress line (IntersectionObserver, no scroll listener).
  useEffect(() => {
    const items = listRef.current?.querySelectorAll('[data-entry]')
    if (!items?.length) return undefined

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActiveIndex(Number(entry.target.dataset.index))
        })
      },
      { rootMargin: '-35% 0px -55% 0px' },
    )
    items.forEach((item) => observer.observe(item))
    return () => observer.disconnect()
  }, [])

  const progress = experiences.length > 1 ? activeIndex / (experiences.length - 1) : 0
  const activeYear = extractYear(experiences[activeIndex]?.period ?? '')

  return (
    <section id="experiencia" className="py-24 md:py-36">
      <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
        <SectionHeading
          index="02"
          title="Experiencia"
          subtitle="Colaboraciones, prácticas y proyectos desarrollados para empresas y clientes reales."
        />

        <div className="grid gap-10 lg:grid-cols-12 lg:gap-16">
          {/* Sticky year + progress rail */}
          <div className="lg:col-span-4">
            <div className="lg:sticky lg:top-32">
              <p
                className="display text-[clamp(5rem,10vw,9rem)] leading-none text-text-primary transition-opacity duration-300"
                aria-live="polite"
              >
                {activeYear}
              </p>
              <div className="mt-8 flex items-center gap-4" aria-hidden="true">
                <span className="u-label text-text-muted">Trayectoria</span>
                <span className="relative h-px flex-1 bg-border">
                  <span
                    className="absolute inset-y-0 left-0 bg-accent transition-[width] duration-500 ease-out"
                    style={{ width: `${Math.round(progress * 100)}%` }}
                  />
                </span>
                <span className="u-label tabular-nums text-text-muted">
                  {String(activeIndex + 1).padStart(2, '0')}/
                  {String(experiences.length).padStart(2, '0')}
                </span>
              </div>
              <p className="u-label mt-6 text-text-muted">
                {experiences[activeIndex]?.kind}
              </p>
            </div>
          </div>

          {/* Entries */}
          <ol ref={listRef} className="lg:col-span-8">
            {experiences.map((item, i) => (
              <li
                key={item.org + item.period}
                data-entry
                data-index={i}
                className={`border-b border-border py-10 first:pt-0 last:border-b-0 md:py-14 transition-opacity duration-300 ${
                  i === activeIndex ? 'opacity-100' : 'opacity-60'
                }`}
              >
                <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
                  <span className="u-label text-accent">{String(i + 1).padStart(2, '0')}</span>
                  <h3 className="text-2xl font-semibold tracking-tight text-text-primary md:text-3xl">
                    {item.role}
                  </h3>
                  <span className="u-label text-text-secondary">{item.org}</span>
                </div>

                <p className="u-label mt-3 text-text-muted">{item.period}</p>

                <p className="mt-5 max-w-2xl text-text-secondary leading-relaxed">{item.summary}</p>

                <p className="mt-5 flex flex-wrap gap-x-2 gap-y-1 font-mono text-xs text-text-muted">
                  {item.technologies.map((tech, idx) => (
                    <span key={tech} className="inline-flex items-baseline gap-2">
                      {idx > 0 && <span aria-hidden="true">/</span>}
                      <span className="cursor-default transition-colors hover:text-accent">{tech}</span>
                    </span>
                  ))}
                </p>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  )
}
