import { useEffect, useRef } from 'react'
import { ArrowRight, ArrowDownRight } from 'lucide-react'
import { site } from '../../data/site'
import Button from '../ui/Button'
import DownloadCVButton from '../ui/DownloadCVButton'
import { useEnvironment } from '../../hooks/useEnvironment'

const specRows = [
  { label: 'Rol', value: site.role },
  { label: 'Base', value: site.location },
  { label: 'Formación', value: 'Téc. Sup. Desarrollo de Aplicaciones Web' },
  { label: 'Estado', value: 'Disponible para nuevas oportunidades', live: true },
  { label: 'Stack', value: 'React · PHP · WordPress' },
]

const nameLines = [
  { text: 'LUIS', depth: 0.05, scroll: 0.18 },
  { text: 'MONTES', depth: 0.085, scroll: 0.3 },
  { text: 'DE OCA', depth: 0.03, scroll: 0.1 },
]

export default function Hero() {
  const year = new Date().getFullYear()
  const { motionEnabled } = useEnvironment()
  const marqueeRef = useRef(null)
  const layersRef = useRef([])

  // Scroll-driven parallax: each name layer + marquee drifts at its own speed.
  useEffect(() => {
    if (!motionEnabled) return undefined
    let raf = 0
    let lastY = window.scrollY

    const update = () => {
      raf = 0
      const y = window.scrollY
      const vh = window.innerHeight
      const t = Math.min(y / vh, 1) // 0 → 1 across the first viewport
      const velocity = y - lastY
      lastY = y

      layersRef.current.forEach((el, i) => {
        if (!el) return
        const conf = nameLines[i]
        if (!conf) return
        el.style.transform = `translate3d(0, ${(-t * conf.scroll * 100).toFixed(2)}px, 0)`
        el.style.opacity = String(Math.max(1 - t * 0.85, 0.15))
      })

      if (marqueeRef.current) {
        const drift = Math.max(-40, Math.min(velocity * 0.6, 40))
        marqueeRef.current.style.setProperty('--marquee-drift', `${drift.toFixed(1)}px`)
      }
    }

    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update)
    }
    update()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => {
      window.removeEventListener('scroll', onScroll)
      if (raf) cancelAnimationFrame(raf)
    }
  }, [motionEnabled])

  return (
    <section
      id="inicio"
      className="relative flex min-h-screen flex-col overflow-hidden pt-24 md:pt-32"
    >
      {/* Layer 0 — background field */}
      <div
        ref={(el) => {
          layersRef.current[3] = el
        }}
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-10"
        style={{ transform: 'translate3d(0,0,0)' }}
      >
        <div className="absolute -right-24 top-24 h-[420px] w-[1px] bg-border md:right-[12%]" />
        <div className="absolute left-[8%] top-[58%] h-px w-[280px] bg-border" />
        <p className="stroke-text display absolute left-[6%] top-[10%] text-[11rem] leading-none opacity-40 md:text-[16rem]">
          26
        </p>
      </div>

      <div className="mx-auto flex w-full max-w-7xl flex-1 flex-col px-5 sm:px-6 lg:px-8">
        {/* Masthead */}
        <div
          ref={(el) => {
            layersRef.current[4] = el
          }}
          className="flex items-center justify-between gap-6 border-b border-border pb-4 pt-2"
        >
          <p className="u-label flex items-center gap-3 text-text-muted">
            <span className="inline-block h-1.5 w-1.5 bg-accent" aria-hidden="true" />
            Portfolio — {site.role} — {year}
          </p>
          <p className="u-label hidden text-text-muted md:block">{site.location}</p>
        </div>

        {/* Monumental name */}
        <div className="flex flex-1 flex-col justify-center py-12 md:py-16">
          <h1 className="sr-only">
            {site.name} — {site.role} en {site.location}
          </h1>
          <div aria-hidden="true" className="select-none">
            {nameLines.map((line, i) => (
              <div
                key={line.text}
                ref={(el) => {
                  layersRef.current[i] = el
                }}
                className={`display will-change-transform ${
                  i === 1
                    ? 'text-[clamp(3.4rem,13vw,11rem)] text-text-primary'
                    : 'stroke-text text-[clamp(3.4rem,13vw,11rem)]'
                } ${i === 2 ? 'pl-[8vw]' : ''} leading-[0.92]`}
                style={{ transition: 'opacity 120ms linear' }}
              >
                {line.text}
              </div>
            ))}
          </div>

          {/* Value line + actions, offset editorially */}
          <div className="mt-10 grid gap-10 lg:grid-cols-12 lg:items-end">
            <div className="lg:col-span-7">
              <p className="text-text-secondary text-lg md:text-xl leading-relaxed max-w-xl">
                {site.headline} {site.subheadline}
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                <Button href="#proyectos" variant="primary" size="lg" data-cursor="view">
                  Ver proyectos
                  <ArrowRight size={18} aria-hidden="true" />
                </Button>
                <Button href="#contacto" variant="secondary" size="lg" data-cursor="talk">
                  Contactar
                </Button>
                <DownloadCVButton variant="ghost" size="lg" label="Descargar CV" />
              </div>
            </div>

            {/* Spec sheet */}
            <aside className="lg:col-span-5 self-stretch border border-border bg-bg-secondary/60 divide-y divide-border">
              {specRows.map((row) => (
                <div key={row.label} className="flex items-start justify-between gap-4 px-4 py-3.5">
                  <span className="u-label shrink-0 pt-0.5 text-text-muted">{row.label}</span>
                  <span
                    className={
                      row.live
                        ? 'inline-flex items-center gap-2 text-right text-sm font-medium text-online'
                        : 'text-right text-sm font-medium text-text-primary'
                    }
                  >
                    {row.live && (
                      <span className="relative flex h-2 w-2 shrink-0" aria-hidden="true">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-online opacity-50" />
                        <span className="relative inline-flex h-2 w-2 rounded-full bg-online" />
                      </span>
                    )}
                    {row.value}
                  </span>
                </div>
              ))}
            </aside>
          </div>
        </div>
      </div>

      {/* Reactive marquee */}
      <div className="marquee border-t border-border py-4" aria-hidden="true">
        <div
          ref={marqueeRef}
          className="marquee-track"
          style={{ '--marquee-drift': '0px' }}
        >
          {[0, 1].map((dup) => (
            <span
              key={dup}
              className="stroke-text display whitespace-nowrap text-[15vw] md:text-[7.5rem]"
            >
              {`Luis Montes de Oca ✦ Desarrollador Web ✦ Madrid ✦ ${year} ✦ `}
            </span>
          ))}
        </div>
      </div>

      <a
        href="#perfil"
        className="u-label absolute bottom-24 right-6 hidden items-center gap-2 text-text-muted transition-colors hover:text-accent lg:right-10 md:inline-flex"
        aria-label="Bajar al perfil"
      >
        Scroll
        <ArrowDownRight size={16} />
      </a>
    </section>
  )
}
