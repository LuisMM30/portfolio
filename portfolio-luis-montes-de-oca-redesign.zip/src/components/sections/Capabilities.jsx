import { ArrowUpRight } from 'lucide-react'
import { capabilities } from '../../data/skills'
import SectionHeading from '../ui/SectionHeading'

export default function Capabilities() {
  return (
    <section id="servicios" className="py-24 md:py-36">
      <div className="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8">
        <SectionHeading index="03" title="Qué puedo construir" />

        <ol className="border-b border-border">
          {capabilities.map((cap, i) => (
            <li key={cap.title}>
              <div className="group grid sm:grid-cols-12 gap-x-8 gap-y-3 items-baseline py-7 md:py-9 border-t border-border transition-colors hover:bg-bg-secondary/50 px-2 -mx-2 sm:px-3 sm:-mx-3">
                <span className="sm:col-span-1 font-mono text-sm text-accent">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <h3 className="sm:col-span-4 text-xl md:text-2xl font-semibold tracking-tight text-text-primary group-hover:text-accent transition-colors">
                  {cap.title}
                </h3>
                <p className="sm:col-span-6 text-text-secondary leading-relaxed max-w-lg">
                  {cap.description}
                </p>
                <span className="sm:col-span-1 justify-self-end text-text-muted transition-all duration-300 group-hover:text-accent group-hover:translate-x-1 group-hover:-translate-y-0.5">
                  <ArrowUpRight size={20} aria-hidden="true" />
                </span>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
