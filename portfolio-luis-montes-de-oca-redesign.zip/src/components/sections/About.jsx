import { site } from '../../data/site'
import { aptitudes } from '../../data/skills'
import SectionHeading from '../ui/SectionHeading'

export default function About() {
  return (
    <section id="sobre-mi" className="py-24 md:py-36">
      <div className="mx-auto max-w-7xl px-5 sm:px-6 lg:px-8">
        <SectionHeading
          index="08"
          title="Construyo productos web para necesidades reales."
          subtitle={site.status}
        />

        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Sticky label column */}
          <div className="lg:col-span-4">
            <div className="lg:sticky lg:top-32">
              <p className="u-label text-text-muted">Sobre mí</p>
              <p className="display mt-6 text-2xl text-text-primary md:text-3xl">
                {site.name}
              </p>
              <p className="u-label mt-3 text-text-muted">
                {site.role} — {site.location}
              </p>
              <div className="mt-10 hidden border-t border-border pt-6 lg:block">
                <p className="u-label text-text-muted">Estado</p>
                <p className="mt-2 inline-flex items-center gap-2 text-sm font-medium text-online">
                  <span className="relative flex h-2 w-2" aria-hidden="true">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-online opacity-50" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-online" />
                  </span>
                  {site.status}
                </p>
              </div>
            </div>
          </div>

          {/* Narrative */}
          <div className="lg:col-span-8">
            <div className="max-w-2xl space-y-6 text-lg text-text-secondary leading-relaxed">
              <p>
                Soy desarrollador web con formación en Desarrollo de Aplicaciones Web y experiencia
                en proyectos para clientes y empresas reales.
              </p>
              <p>
                He trabajado en comercio electrónico, webs para negocios y en el desarrollo desde
                cero de una plataforma de gestión de pedidos con React y MongoDB.
              </p>
              <p>
                También integro herramientas de inteligencia artificial en mi flujo de trabajo para
                investigar soluciones, acelerar el desarrollo y mejorar la productividad.
              </p>
              <p>
                Busco nuevas oportunidades donde pueda aportar valor en proyectos tecnológicos y
                seguir creciendo.
              </p>
            </div>

            <div className="mt-20 md:mt-28">
              <p className="u-label mb-8 text-text-muted">Más allá del código</p>
              <ol className="border-b border-border sm:grid sm:grid-cols-2 lg:grid-cols-3">
                {aptitudes.map((aptitude, i) => (
                  <li
                    key={aptitude}
                    className="flex items-baseline gap-4 border-t border-border py-5 pr-6"
                  >
                    <span className="shrink-0 font-mono text-xs text-accent">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className="font-medium leading-snug text-text-primary">{aptitude}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
