export const site = {
  name: 'Luis Montes de Oca',
  role: 'Desarrollador Web',
  location: 'Madrid, España',
  status: 'Disponible para nuevas oportunidades',
  email: 'luismonteswebs@gmail.com',
  linkedin: 'https://www.linkedin.com/in/luis-montes-de-oca-81383732a',
  education: 'Técnico Superior en Desarrollo de Aplicaciones Web',
  headline: 'Desarrollo webs y aplicaciones para proyectos reales.',
  subheadline:
    'Trabajo en experiencias web, comercio electrónico y aplicaciones que resuelven necesidades reales.',
  mainTech: ['React', 'JavaScript', 'TypeScript', 'PHP', 'WordPress'],
  highlights: ['Proyectos reales', 'E-commerce', 'Aplicaciones web'],
}

export const cv = {
  fileName: 'DESARROLLADOR-WEB-LUIS-MONTES-DE-OCA.pdf',
  url: '/cv/DESARROLLADOR-WEB-LUIS-MONTES-DE-OCA.pdf',
}

export const navLinks = [
  { label: 'Proyectos', href: '#proyectos' },
  { label: 'Experiencia', href: '#experiencia' },
  { label: 'Tecnologías', href: '#tecnologias' },
  { label: 'Sobre mí', href: '#sobre-mi' },
  { label: 'Contacto', href: '#contacto' },
]

export const contactReasons = [
  'Oportunidad laboral',
  'Proyecto web',
  'E-commerce',
  'Aplicación web',
  'Otro',
]
