export const education = [
  {
    title: 'Grado Superior en Desarrollo de Aplicaciones Web',
    subtitle: 'Modalidad Dual',
    center: 'IES Emperatriz María de Austria',
    location: 'Madrid',
    period: '2023 — 2025',
  },
  {
    title: 'Bachillerato Científico-Tecnológico',
    subtitle: null,
    center: 'IES Pío Baroja',
    location: 'Madrid',
    period: null,
  },
]

export const languages = [
  { language: 'Español', level: 'Nativo' },
  { language: 'Inglés', level: 'B2.2' },
]
