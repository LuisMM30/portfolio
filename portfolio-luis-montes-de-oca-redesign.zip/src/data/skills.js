export const skillCategories = [
  {
    title: 'Frontend',
    skills: ['HTML', 'CSS', 'JavaScript', 'TypeScript', 'React'],
  },
  {
    title: 'Backend y datos',
    skills: ['PHP', 'MySQL', 'MongoDB', 'SQL'],
  },
  {
    title: 'CMS y E-commerce',
    skills: ['WordPress', 'WooCommerce', 'PrestaShop'],
  },
  {
    title: 'Herramientas',
    skills: ['Git', 'GitHub', 'VS Code', 'Excel', 'Make'],
  },
]

export const capabilities = [
  {
    title: 'Webs para negocios',
    description: 'Webs corporativas y experiencias digitales para empresas y profesionales.',
    icon: 'building',
  },
  {
    title: 'E-commerce',
    description: 'Tiendas online y catálogos de productos con WordPress y WooCommerce.',
    icon: 'shopping',
  },
  {
    title: 'Aplicaciones web',
    description: 'Interfaces y herramientas para gestionar procesos y datos.',
    icon: 'app',
  },
  {
    title: 'Integraciones y datos',
    description: 'Trabajo con APIs, bases de datos y flujos de información.',
    icon: 'database',
  },
]

export const aptitudes = [
  'Desarrollo web moderno',
  'Gestión y optimización de e-commerce',
  'Integración de IA en desarrollo web',
  'Resolución de problemas técnicos',
  'Diseño responsive y experiencia UX',
  'Aprendizaje rápido y adaptación tecnológica',
]

export const workSteps = [
  {
    number: '01',
    title: 'Entender',
    description: 'Comprender el proyecto, sus necesidades y objetivos.',
  },
  {
    number: '02',
    title: 'Planificar',
    description: 'Definir una solución clara y una estructura adecuada.',
  },
  {
    number: '03',
    title: 'Desarrollar',
    description: 'Construir la solución y trabajar sobre las funcionalidades necesarias.',
  },
  {
    number: '04',
    title: 'Mejorar',
    description: 'Revisar, ajustar y optimizar la experiencia.',
  },
]
