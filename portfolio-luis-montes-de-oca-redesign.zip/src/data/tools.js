export const toolCategories = [
  {
    title: 'Desarrollo',
    tools: ['Git', 'GitHub', 'VS Code', 'OpenCode'],
  },
  {
    title: 'Inteligencia Artificial',
    tools: ['Claude', 'GitHub Copilot', 'Cursor', 'Codex', 'Gemini', 'DALL·E', 'Ollama'],
  },
  {
    title: 'Productividad y automatización',
    tools: ['Make', 'Excel', 'Canva'],
  },
]

export const aiMessage =
  'Utilizo herramientas de inteligencia artificial como parte de mi flujo de desarrollo para investigar, acelerar tareas, resolver problemas y mejorar la productividad.'
