// Experiencia profesional.
// NOTA: revisa empresas, roles y fechas contra tu CV real antes de publicar.
// Cada entrada se muestra como un paso de la línea temporal, de más reciente a más antigua.
export const experiences = [
  {
    period: 'Marzo 2026 — Junio 2026',
    role: 'Plataforma web de gestión de pedidos',
    org: 'Proyecto para una empresa real',
    kind: 'Aplicación web · Desarrollo desde cero',
    summary:
      'Desarrollo desde cero de una plataforma web para la gestión de pedidos de una empresa, con React en el frontend y MongoDB como base de datos. Código propio gestionado con GitHub y desarrollo asistido por IA.',
    technologies: ['React', 'MongoDB', 'GitHub', 'VS Code'],
  },
  {
    period: 'Octubre 2025 — Febrero 2026',
    role: 'Desarrollador Web',
    org: 'Awakelab',
    kind: 'Colaboración profesional',
    summary:
      'Colaboración con un autónomo en el desarrollo de webs completas para clientes reales con WordPress y tecnologías complementarias, gestión de bases de datos en Excel y entrega directa a clientes con requerimientos concretos.',
    technologies: ['WordPress', 'Excel'],
  },
  {
    period: 'Septiembre 2024 — Junio 2025',
    role: 'Desarrollador Web',
    org: 'LaPrimeraWeb',
    kind: 'Prácticas · Grado Superior',
    summary:
      'Prácticas del Grado Superior en una empresa real: desarrollo web, diseño digital y captación. Creación de webs con HTML, CSS, JavaScript, WordPress y PrestaShop, diseño de recursos visuales, gestión de bases de datos y automatización con Make.',
    technologies: ['HTML', 'CSS', 'JavaScript', 'WordPress', 'PrestaShop', 'Make'],
  },
]
